import postgres from "postgres";

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  });
}

function authorized(request, env) {
  const expected = env.API_SECRET;
  return Boolean(expected && request.headers.get("X-API-Secret") === expected);
}

async function verifyLicense(body, env) {
  const key = String(body?.key || "").trim();
  const telegramId = String(body?.telegram_id || "").trim();
  if (!key || !/^\\d+$/.test(telegramId)) return false;
  const endpoint = env.LICENSE_VERIFY_URL || "https://supergram.onrender.com/activate";
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: { "content-type": "application/json", "accept": "application/json" },
      body: JSON.stringify({ key, telegram_id: telegramId }),
    });
    const result = await response.json();
    return response.ok && result?.ok === true;
  } catch {
    return false;
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;
    if (!env.HYPERDRIVE?.connectionString) return json({ ok: false, error: "HYPERDRIVE_NOT_CONFIGURED" }, 500);

    const sql = postgres(env.HYPERDRIVE.connectionString, {
      max: 1,
      fetch_types: false,
      prepare: false,
    });

    try {
      await sql`
        CREATE TABLE IF NOT EXISTS global_nfts (
          id BIGSERIAL PRIMARY KEY,
          nft_key TEXT UNIQUE NOT NULL,
          title TEXT NOT NULL DEFAULT '',
          owner_id TEXT NOT NULL DEFAULT '',
          serial_number BIGINT,
          comment TEXT NOT NULL DEFAULT '',
          nft_date TEXT NOT NULL DEFAULT '',
          updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
      `;
      await sql`
        CREATE TABLE IF NOT EXISTS global_nft_items (
          id BIGSERIAL PRIMARY KEY,
          publisher_id BIGINT NOT NULL,
          dialog_id BIGINT NOT NULL,
          item_key TEXT NOT NULL,
          payload JSONB NOT NULL,
          updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
          UNIQUE (publisher_id, dialog_id, item_key)
        )
      `;
      await sql`CREATE INDEX IF NOT EXISTS global_nft_items_dialog_idx ON global_nft_items(dialog_id)`;
      await sql`
        CREATE TABLE IF NOT EXISTS global_bans (
          account_id TEXT PRIMARY KEY,
          reason TEXT NOT NULL DEFAULT '',
          created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
      `;

      if (path === "/" || path === "/health") {
        await sql`SELECT 1 AS connected`;
        return json({ ok: true, service: "supergram-global-api", database: "connected" });
      }

      if (path === "/nft" && request.method === "GET") {
        const rows = await sql`
          SELECT nft_key, title, owner_id, serial_number, comment, nft_date, updated_at
          FROM global_nfts ORDER BY updated_at DESC LIMIT 1000
        `;
        return json({ ok: true, nfts: rows });
      }

      // Compatibility with the existing SuperGrammod NFT registry protocol.
      if (path === "/nft/sync" && request.method === "POST") {
        const body = await request.json().catch(() => null);
        if (!body || typeof body !== "object") return json({ ok: false, error: "INVALID_JSON" }, 400);

        if (Array.isArray(body.items)) {
          const publisherId = Number(body.telegram_id || 0);
          if (!Number.isSafeInteger(publisherId) || publisherId <= 0) {
            return json({ ok: false, error: "MISSING_ACCOUNT_OR_LICENSE" }, 401);
          }
          if (!(await verifyLicense(body, env))) {
            return json({ ok: false, error: "LICENSE_NOT_VERIFIED" }, 401);
          }
          const items = body.items.slice(0, 60);
          if (body.replace_all === true) {
            await sql`DELETE FROM global_nft_items WHERE publisher_id = ${publisherId}`;
          }
          let stored = 0;
          for (const item of items) {
            if (!item || typeof item !== "object") continue;
            const dialogId = Number(item.dialog_id || 0);
            const itemKey = String(item.key || "");
            if (!itemKey) continue;
            await sql`
              INSERT INTO global_nft_items (publisher_id, dialog_id, item_key, payload, updated_at)
              VALUES (${publisherId}, ${Number.isSafeInteger(dialogId) ? dialogId : 0}, ${itemKey}, ${sql.json({ ...item, publisher_id: publisherId })}, NOW())
              ON CONFLICT (publisher_id, dialog_id, item_key)
              DO UPDATE SET payload = EXCLUDED.payload, updated_at = NOW()
            `;
            stored++;
          }
          return json({ ok: true, stored });
        }

        // New simple metadata format for manual/API integrations.
        if (!authorized(request, env)) return json({ ok: false, error: "UNAUTHORIZED" }, 401);
        if (!Array.isArray(body.nfts)) return json({ ok: false, error: "NFTS_ARRAY_REQUIRED" }, 400);
        let stored = 0;
        for (const item of body.nfts.slice(0, 1000)) {
          if (!item || !item.nft_key) continue;
          await sql`
            INSERT INTO global_nfts (nft_key, title, owner_id, serial_number, comment, nft_date, updated_at)
            VALUES (
              ${String(item.nft_key)},
              ${String(item.title || "")},
              ${String(item.owner_id || "")},
              ${item.serial_number == null ? null : Number(item.serial_number)},
              ${String(item.comment || "")},
              ${String(item.nft_date || "")},
              NOW()
            )
            ON CONFLICT (nft_key) DO UPDATE SET
              title = EXCLUDED.title,
              owner_id = EXCLUDED.owner_id,
              serial_number = EXCLUDED.serial_number,
              comment = EXCLUDED.comment,
              nft_date = EXCLUDED.nft_date,
              updated_at = NOW()
          `;
          stored++;
        }
        return json({ ok: true, stored });
      }

      if (path === "/nft/lookup" && request.method === "POST") {
        const body = await request.json().catch(() => null);
        if (!body || !Array.isArray(body.targets)) return json({ ok: false, error: "TARGETS_ARRAY_REQUIRED" }, 400);
        if (!(await verifyLicense(body, env))) {
          return json({ ok: false, error: "LICENSE_NOT_VERIFIED" }, 401);
        }
        const users = {};
        for (const target of body.targets.slice(0, 50)) {
          const id = Number(target);
          if (!Number.isSafeInteger(id) || id <= 0) continue;
          const rows = await sql`
            SELECT payload FROM global_nft_items
            WHERE dialog_id = ${id}
            ORDER BY updated_at DESC LIMIT 60
          `;
          users[String(id)] = rows.map((row) => row.payload);
        }
        return json({ ok: true, users });
      }

      if (path === "/ban/check" && request.method === "GET") {
        const accountId = String(url.searchParams.get("account_id") || "");
        if (!accountId) return json({ ok: false, error: "ACCOUNT_ID_REQUIRED" }, 400);
        const rows = await sql`SELECT account_id, reason, created_at FROM global_bans WHERE account_id = ${accountId} LIMIT 1`;
        return json({ ok: true, banned: rows.length > 0, ban: rows[0] || null });
      }

      if (path === "/ban" && request.method === "POST") {
        if (!authorized(request, env)) return json({ ok: false, error: "UNAUTHORIZED" }, 401);
        const body = await request.json().catch(() => null);
        const accountId = String(body?.account_id || "");
        if (!accountId) return json({ ok: false, error: "ACCOUNT_ID_REQUIRED" }, 400);
        const reason = String(body?.reason || "").slice(0, 500);
        const rows = await sql`
          INSERT INTO global_bans (account_id, reason) VALUES (${accountId}, ${reason})
          ON CONFLICT (account_id) DO UPDATE SET reason = EXCLUDED.reason, created_at = NOW()
          RETURNING account_id, reason, created_at
        `;
        return json({ ok: true, ban: rows[0] });
      }

      if (path === "/ban" && request.method === "DELETE") {
        if (!authorized(request, env)) return json({ ok: false, error: "UNAUTHORIZED" }, 401);
        const accountId = String(url.searchParams.get("account_id") || "");
        if (!accountId) return json({ ok: false, error: "ACCOUNT_ID_REQUIRED" }, 400);
        const rows = await sql`DELETE FROM global_bans WHERE account_id = ${accountId} RETURNING account_id`;
        return json({ ok: true, removed: rows.length > 0 });
      }

      return json({ ok: false, error: "NOT_FOUND" }, 404);
    } catch (error) {
      return json({ ok: false, error: "INTERNAL_ERROR", detail: String(error?.message || error).slice(0, 240) }, 500);
    } finally {
      await sql.end({ timeout: 1 }).catch(() => {});
    }
  },
};
